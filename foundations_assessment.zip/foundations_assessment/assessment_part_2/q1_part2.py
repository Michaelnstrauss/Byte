

user_string = input('enter string here: ')

all_caps_string = user_string.upper()
all_caps_string = all_caps_string.split()

for item in all_caps_string:
    print(item)
print('!')


# word_string = ''

# for word in all_caps_string:
#     word_string += word
# print('{}!'.format(word_string))


#print('{}!'.format(all_caps))