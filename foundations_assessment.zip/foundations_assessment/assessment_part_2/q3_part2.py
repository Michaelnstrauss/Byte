

d = {
    'Carter': 'value',
    'Greg': ['list', 'of', 'values'],
    'Kenso': 'VALUE'
}

d['Nikhil'] = 'another value'

print(d['Carter'])

print(d['Greg'][1])