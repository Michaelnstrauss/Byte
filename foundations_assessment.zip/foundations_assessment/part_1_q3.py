

for num in range(0,51):
    if num % 7 != 0:
        print(num)
